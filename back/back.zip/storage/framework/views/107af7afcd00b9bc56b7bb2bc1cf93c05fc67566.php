<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('idiom')); ?>

            <?php echo e(Form::text('idiom', $product->idiom, ['class' => 'form-control' . ($errors->has('idiom') ? ' is-invalid' : ''), 'placeholder' => 'Idiom'])); ?>

            <?php echo $errors->first('idiom', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('name')); ?>

            <?php echo e(Form::text('name', $product->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

            <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('description_es')); ?>

            <?php echo e(Form::text('description_es', $product->description_es, ['class' => 'form-control' . ($errors->has('description_es') ? ' is-invalid' : ''), 'placeholder' => 'Description Es'])); ?>

            <?php echo $errors->first('description_es', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('description_en')); ?>

            <?php echo e(Form::text('description_en', $product->description_en, ['class' => 'form-control' . ($errors->has('description_en') ? ' is-invalid' : ''), 'placeholder' => 'Description En'])); ?>

            <?php echo $errors->first('description_en', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('status')); ?>

            <?php echo e(Form::text('status', $product->status, ['class' => 'form-control' . ($errors->has('status') ? ' is-invalid' : ''), 'placeholder' => 'Status'])); ?>

            <?php echo $errors->first('status', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\londonbeds\back\resources\views\product\form.blade.php ENDPATH**/ ?>