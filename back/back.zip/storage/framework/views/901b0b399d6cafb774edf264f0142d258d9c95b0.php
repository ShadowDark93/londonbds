<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('name')); ?>

            <?php echo e(Form::text('name', $section->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Name'])); ?>

            <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('idiom')); ?>

            <?php echo e(Form::text('idiom', $section->idiom, ['class' => 'form-control' . ($errors->has('idiom') ? ' is-invalid' : ''), 'placeholder' => 'Idiom'])); ?>

            <?php echo $errors->first('idiom', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('text')); ?>

            <?php echo e(Form::text('text', $section->text, ['class' => 'form-control' . ($errors->has('text') ? ' is-invalid' : ''), 'placeholder' => 'Text'])); ?>

            <?php echo $errors->first('text', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\londonbeds\back\resources\views\section\form.blade.php ENDPATH**/ ?>