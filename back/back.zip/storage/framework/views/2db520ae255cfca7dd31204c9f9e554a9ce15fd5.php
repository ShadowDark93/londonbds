

<?php $__env->startSection('template_title'); ?>
    <?php echo e($socialNetwork->name ?? 'Show Social Network'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Social Network</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('social-networks.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Name:</strong>
                            <?php echo e($socialNetwork->name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Url:</strong>
                            <?php echo e($socialNetwork->url); ?>

                        </div>
                        <div class="form-group">
                            <strong>Logo:</strong>
                            <?php echo e($socialNetwork->logo); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\londonbeds\back\resources\views\social-network\show.blade.php ENDPATH**/ ?>